
package project;

public class Patient {

    String pID;
    String name;
    
    int age;
    String reason;
    //int dateTime;
    

    public Patient(String pID, String name, int age, String reason) {
        this.pID = pID;
        this.name = name;
        this.age = age;
        this.reason = reason;
       // this.dateTime = dateTime;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getReason() {
        return reason;
    }

    public String getID() {
        return pID;
    }
    /*public int GetDateTime(){
       return dateTime;
    }*/

    @Override
    public String toString() {
        return "Patient ID: " + pID + "\n" + "Name: " + name + "\n" + "Age: " + age + "\n" + "Reason: " + reason;
    }

}
