/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package project;

/**
 *
 * @author Students Account
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.security.SecureRandom;


public class HospitalManagementSystem {

    public static final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    private static final SecureRandom random = new SecureRandom();

    public static void Menu() {
        System.out.print(""" 
                           ::::::::::::::::::::::::::::
                           |HOSPITAL MANAGEMENT SYSTEM|
                           ::::::::::::::::::::::::::::  
                            ===========MENU===========
                           
                           1. Register New Patient
                           2. View Patient Consultation Queue
                           3. Call Next Patient For Consultation
                           4. Discharge patient 
                           5. View currently admitted patient/s
                           6. View recently discharged patient/s
                           7. View all patient records
                           8. Search patient record
                           9. Exit
                           
                           Choice: """
        );

    }

    public static String generateUniqueID(int length) {

        StringBuilder code = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            code.append(chars.charAt(random.nextInt(chars.length())));
        }
        return code.toString();
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        PatientRecordLinkedList record = new PatientRecordLinkedList();
        PatientQueue pqueue = new PatientQueue(10);
        AdmittedList admit = new AdmittedList();
        RecentlyDischarged discharged = new RecentlyDischarged(10);
        Patient patient;
        String[] consulting = new String[1];
        int length = 6;

        int choice = 0;
        while (true) {
            Menu();
            choice = input.nextInt();
            input.nextLine();
            OUTER:
            switch (choice) {
                case 1:

                    System.out.print("Enter Name: ");
                    String name = input.nextLine();

                    System.out.print("Enter Age: ");
                    int age = input.nextInt();
                    input.nextLine();

                    System.out.print("Enter Reason: ");
                    String reason = input.nextLine();
                    
                    //List<Patient> foundSimilar= record.searchSimilarRecord(name);
                    
                    /*if(!foundSimilar.isEmpty()){
                        System.out.print("""
                                           Is this the same patient? (Yes/No)
                                           > 
                                           """);
                        String conf = input.nextLine();
                        if(conf.equalsIgnoreCase("Yes")){
                            pqueue.enqueue((Patient)foundSimilar);
                            System.out.println("Patient Succesfully Queued.");
                            break;
                        }
                    }*/
                    
                    

                    System.out.println(""" 
                                       
                                       Are you sure you want to add this record? 
                                       (yes/press any key to cancel) 
                                       >
                                       """);

                    String conf = input.nextLine();
                    if (conf.equalsIgnoreCase("yes")) {
                        String ID = "HMS-" + generateUniqueID(length);
                        
                        patient = new Patient(ID, name, age, reason);
                        record.insertEnd(patient);
                        pqueue.enqueue(patient);
                        System.out.println("Succesfully Recorded. Patient added to queue.");
                    }
                    else{
                        break;
                    }

                    break;
                case 2:
                    if (pqueue.isEmpty()) {
                        System.out.println("Queue is empty.");
                        break;
                    }

                    pqueue.displayQueue();
                    break;
                case 3:
                    if (pqueue.isEmpty()) {
                        System.out.println("Queue is empty.");
                        break;
                    }
                    Patient removed = pqueue.dequeue();
                    consulting[0] = removed.getName();
                    System.out.println("Patient " + removed.getName() + " has been called for consultation.");
                    System.out.println("Patient under consultation: " + consulting[0]);
                    System.out.println("""
                                                           1. Admit to hospital
                                                           2. Discharge with outpatient medication
                                                           3. Back
                                       
                                                           Choice:
                                                           """);
                    int cchoice = input.nextInt();

                    switch (cchoice) {
                        case 1:
                            System.out.println("Patient " + removed.getName() + " has been admitted to the hospital.");
                            admit.insertFirst(removed);
                            break OUTER;
                        case 2:
                            System.out.println("Patient discharged with outpatient medication.");
                            break OUTER;
                        case 3:
                            break OUTER;
                        default:
                            System.out.println("");
                            break;
                    }

                    break;
                case 4:
                    if (admit.isEmpty()) {
                        System.out.println("There are no patients currently admitted.");
                        break;
                    }
                    System.out.println("Enter Patient ID to discharge: ");
                    String searchID = input.nextLine();

                    String checkiffound = admit.searchByPatientID(searchID);
                    if (checkiffound == null) {
                        break;
                    }
                    System.out.print("""
                                                           Are you sure you want to continue?
                                                           (yes/press any key to cancel)
                                       
                                                           Choice:
                                                           """);
                    String sel = input.nextLine();

                    if (sel.equalsIgnoreCase("Yes")) {
                        int count = admit.listCount();
                        if (count == 1) {
                            Patient deleted = admit.deleteFirst();
                            System.out.println("Patient " + deleted.getName() + " successfully discharged.");
                            discharged.push(deleted);
                            break;
                        } else {
                            Patient ptnt = admit.deleteByID(searchID);
                            discharged.push(ptnt);
                            System.out.println("Patient " + ptnt.getName() + " successfully discharged.");

                        }
                    } else {
                        break;
                    }
                    break;
                case 5:
                    if (admit.isEmpty()) {
                        System.out.println("List is empty.");
                        break;
                    }

                    admit.display();
                    break;
                case 6: 
                    discharged.displayStack();
                    break;
                case 7:
                    if (record.isEmpty()) {
                        System.out.println("Record is empty.");
                        break;
                    }
                    record.display();
                    break;
                case 8:
                    if(record.isEmpty()){
                        System.out.println("Record is empty.");
                        break;
                    }
                    System.out.println("Enter patient ID to search: ");
                    String searchRecord = input.nextLine();
                    record.searchByPatientID(searchRecord);
                            
                    break;
                case 9:
                    System.out.println("Exiting Program. Thank You!");
                    return;
            }

        }
    }

}
