package project;

public class AdmittedList {

    private Node head;

    public class Node {

        public Patient data;
        public Node next;

        Node(Patient data) {
            this.data = data;
            this.next = null;
        }
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void insertFirst(Patient data) {
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
    }

    public void insertEnd(Patient data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            return;
        }
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
    }

    public void reverse() {
        if (head == null) {
            System.out.println("\nList is empty.");
            return;
        }
        Node current = head;
        Node previous = null;

        while (current != null) {
            Node next = current.next;
            current.next = previous;
            previous = current;
            current = next;
        }
        head = previous;

        System.out.println("List Reversed:");
        display();
    }

    public void insertMid(Patient data, int pos) {
        int count = listCount();
        if (pos < 1 || pos > count + 1) {
            System.out.println("Out of bounds.");
            return;
        }
        if (head == null || pos == 1) {
            insertFirst(data);
            return;
        }
        if (count == 1 && pos > 1) {
            insertEnd(data);
            return;
        }
        Node newNode = new Node(data);
        Node current = head;
        for (int i = 1; i < pos - 1; i++) {
            current = current.next;
        }
        newNode.next = current.next;
        current.next = newNode;
    }

    public Patient deleteFirst() {
        if (head == null) {
            return null;
        }
        Patient deletedData = head.data;
        head = head.next;
        return deletedData;
    }

    public Patient deleteEnd() {
        if (head == null) {
            return null;
        }
        if (head.next == null) {
            Patient deletedData = head.data;
            head = null;
            return deletedData;
        }
        Node current = head;
        while (current.next.next != null) {
            current = current.next;
        }
        Patient deletedData = current.next.data;
        current.next = null;
        return deletedData;
    }

    public Patient deleteMid(int pos) {
        int count = listCount();
        if (pos < 1 || pos > count || head == null) {
            return null;
        }
        if (pos == 1) {
            return deleteFirst();
        }
        Node current = head;
        for (int i = 1; i < pos - 1; i++) {
            current = current.next;
        }
        Patient deletedData = current.next.data;
        current.next = current.next.next;
        return deletedData;
    }

    public void display() {
        if (head == null) {
            System.out.println("\nList is empty.");
            return;
        }
        Node current = head;
        while (current != null) {
            System.out.print(current.data);
            current = current.next;
        }

    }

    public Patient getFirstValue() {
        if (head == null) {
            return null;
        }
        return head.data;
    }

    public void searchByName(String name) {
        if (head == null) {
            System.out.println("List is empty. There is none to search.");
            return;
        }

        Node current = head;
        int position = 1;
        boolean found = false;

        while (current != null) {
            if (current.data.getName().equalsIgnoreCase(name)) {
                System.out.println("Patient \"" + name + " found.");
                System.out.println("Details: Name: " + current.data.getName()
                        + ", Age: " + current.data.getAge()
                        + ", Reason: " + current.data.getReason());
                found = true;
            }
            current = current.next;
            position++;
        }

        if (!found) {
            System.out.println("Patient \"" + name + "\" not found in the list.");
        }
    }

    public String searchByPatientID(String id) {
        if (head == null) {
            System.out.println("List is empty. There is none to search.");
            return null;
        }

        Node current = head;
        int position = 1;
        boolean found = false;

        while (current != null) {
            if (current.data.getID().equalsIgnoreCase(id)) {
                System.out.println("Patient with ID " + id);
                System.out.println("Details: \n Name: " + current.data.getName() + "\n"
                        + "Age: " + current.data.getAge() + "\n"
                        + "Reason: " + current.data.getReason());
                found = true;
            }
            current = current.next;
            position++;
        }

        if (!found) {
            System.out.println("Patient with ID \"" + id + "\" not found in the list.");
            return null;
        }
        return id;
    }

    public Patient deleteByID(String id) {
        Node current = head;
        int position = 1;
        

        while (current != null) {
            if (current.data.getID().equalsIgnoreCase(id)) {
                Patient deletedPatient = current.data; // store the patient to return later
                deleteMid(position); // perform the deletion based on position
                return deletedPatient; // return the deleted patient
            }
            current = current.next;
            position++;
        }

        // If not found
        System.out.println("Patient with ID \"" + id + "\" not found.");
        return null;
    }

    public Patient searchByIndex(int position) {
        int count = listCount();
        if (position < 1 || position > count) {
            return null;
        }
        Node current = head;
        for (int i = 1; i < position; i++) {
            current = current.next;
        }
        return current.data;
    }

    public int listCount() {
        int count = 0;
        Node current = head;
        while (current != null) {
            count++;
            current = current.next;
        }
        return count;
    }
}
