
package project;

public class Patient {

    String pID;
    String name;
    int age;
    String reason;

    public Patient(String pID, String name, int age, String reason) {
        this.pID = pID;
        this.name = name;
        this.age = age;
        this.reason = reason;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getReason() {
        return reason;
    }

    public String getID() {
        return pID;
    }

    @Override
    public String toString() {
        return "Patient ID: " + pID + "\n" + "Name: " + name + "\n" + "Age: " + age + "\n" + "Reason: " + reason + "\n" + "\n";
    }

}
