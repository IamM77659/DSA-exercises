package project;

public class PatientQueue {

    private Patient[] myArray;
    private int front, rear, count, maxSize;

    // constructor
    public PatientQueue(int size) {
        myArray = new Patient[size];
        count = 0;
        front = -1;
        rear = -1;
        maxSize = size;
    }

    public void enqueue(Patient add) {
        if (!isFull()) {
            if (rear == maxSize - 1) {
                rear = -1; // wrap around
            }
            if (front == -1) {
                front = 0;
            }
            myArray[++rear] = add;
            count++;
        } else {
            System.out.println("Queue is full.");
        }
    }

    public Patient dequeue() {
        if (!isEmpty()) {
            Patient removed = myArray[front];
            myArray[front] = null;
            front = (front + 1) % maxSize;
            count--;
            return removed;
        } else {
            System.out.println("Queue is empty.");
            return null;
        }
    }

    public boolean isFull() {
        return count == maxSize;
    }

    public boolean isEmpty() {
        return count == 0;
    }

    public int queueCount() {
        return count;
    }

    public Patient peek() {
        if (!isEmpty()) {
            return myArray[front];
        } else {
            System.out.println("Queue is empty.");
            return null;
        }
    }

    public Patient rear() {
        if (!isEmpty()) {
            return myArray[rear];
        } else {
            System.out.println("Queue is empty.");
            return null;
        }
    }

    public void displayQueue() {
        int pcount = 0;
        if (isEmpty()) {
            System.out.println("Queue is empty.");
        } else {
            System.out.println("Patients in queue:");
            int index = front;
            for (int i = 0; i < count; i++) {
                pcount ++;
                System.out.println("Queue " + "# " + pcount);
                System.out.println(myArray[index]);
                
                index = (index + 1) % maxSize;
            }
        }
    }
}
