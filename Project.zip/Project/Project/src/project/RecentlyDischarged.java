package project;

public class RecentlyDischarged {

    private Patient[] arr;
    private int top;
    private int capacity;

    public RecentlyDischarged(int size) {
        arr = new Patient[size];
        capacity = size;
        top = -1;
    }

    public void push(Patient item) {
        if (isFull()) {
            System.out.println("Storage is full.");
        } else {
            arr[++top] = item;
            System.out.println("Patient added to Recently Discharged: " + item.getName());
        }
    }

    public Patient pop() {
        if (isEmpty()) {
            System.out.println("Record is empty.");
            return null;
        }
        Patient popped = arr[top--];
        System.out.println("Patient removed from Recently Discharged record: " + popped.getName());
        return popped;
    }

    public Patient top() {
        if (isEmpty()) {
            System.out.println("Record is empty.");
            return null;
        }
        return arr[top];
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public boolean isFull() {
        return top == capacity - 1;
    }

    public int size() {
        return top + 1;
    }

    public void displayStack() {
        if (isEmpty()) {
            System.out.println("Recently Discharged record is empty.");
        } else {
            System.out.println("===Recently Discharged Patients===");
            for (int i = top; i >= 0; i--) {
                Patient p = arr[i];
                System.out.println(" - " + p.getName() + " (ID: " + p.getID() + ")");
            }
        }
    }
}
