package project;

public class PatientRecordLinkedList {

    private Node head;

    private class Node {
        String data;
        Node next;

        Node(String data) {
            this.data = data;
            this.next = null;
        }
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void insertFirst(String data) {
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
    }

    public void insertEnd(String data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            return;
        }
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
    }

    public void reverse() {
        if (head == null) {
            System.out.println("\nList is empty.");
            return;
        }
        Node current = head;
        Node previous = null;

        while (current != null) {
            Node next = current.next;
            current.next = previous;
            previous = current;
            current = next;
        }
        head = previous;

        System.out.println("List Reversed:");
        display();
    }

    public void insertMid(String data, int pos) {
        int count = listCount();
        if (pos < 1 || pos > count + 1) {
            System.out.println("Out of bounds.");
            return;
        }
        if (head == null || pos == 1) {
            insertFirst(data);
            return;
        }
        if (count == 1 && pos > 1) {
            insertEnd(data);
            return;
        }
        Node newNode = new Node(data);
        Node current = head;
        for (int i = 1; i < pos - 1; i++) {
            current = current.next;
        }
        newNode.next = current.next;
        current.next = newNode;
    }

    public String deleteFirst() {
        if (head == null) {
            return null;
        }
        String deletedData = head.data;
        head = head.next;
        return deletedData;
    }

    public String deleteEnd() {
        if (head == null) {
            return null;
        }
        if (head.next == null) {
            String deletedData = head.data;
            head = null;
            return deletedData;
        }
        Node current = head;
        while (current.next.next != null) {
            current = current.next;
        }
        String deletedData = current.next.data;
        current.next = null;
        return deletedData;
    }

    public String deleteMid(int pos) {
        int count = listCount();
        if (pos < 1 || pos > count || head == null) {
            return null;
        }
        if (pos == 1) {
            return deleteFirst();
        }
        Node current = head;
        for (int i = 1; i < pos - 1; i++) {
            current = current.next;
        }
        String deletedData = current.next.data;
        current.next = current.next.next;
        return deletedData;
    }

    public void display() {
        if (head == null) {
            System.out.println("\nList is empty.");
            return;
        }
        Node current = head;
        while (current != null) {
            System.out.print("[" + current.data + "] -> ");
            current = current.next;
        }
        System.out.println("null");
    }

    public String getFirstValue() {
        if (head == null) {
            return null;
        }
        return head.data;
    }

    public void searchByValue(String data) {
        if (head == null) {
            System.out.println("List is empty. There is none to search.");
            return;
        }
        Node current = head;
        int position = 1;
        boolean found = false;

        while (current != null) {
            if (current.data.equals(data)) {
                System.out.println("Value \"" + data + "\" found at index " + position);
                found = true;
            }
            current = current.next;
            position++;
        }

        if (!found) {
            System.out.println("Value \"" + data + "\" not found in the list.");
        }
    }

    public String searchByIndex(int position) {
        int count = listCount();
        if (position < 1 || position > count) {
            return null;
        }
        Node current = head;
        for (int i = 1; i < position; i++) {
            current = current.next;
        }
        return current.data;
    }

    public int listCount() {
        int count = 0;
        Node current = head;
        while (current != null) {
            count++;
            current = current.next;
        }
        return count;
    }
}