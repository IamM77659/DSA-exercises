/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package project;

/**
 *
 * @author Students Account
 */
import java.util.Scanner;

public class Project {

    public static void Menu() {
        System.out.print(""" 
                           Hospital Management System
                           ===========MENU===========
                           
                           1. Register New Patient
                           2. View Patient Consultation Queue
                           3. Call Next Patient For Consultation 
                           4. Discharge patient 
                           5. View recently discharged patient
                           6. View all patient records
                           7. Search patient record
                           8. Exit
                           
                           Choice: """
        );

    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        PatientRecordLinkedList list = new PatientRecordLinkedList();

        while (true) {
            Menu();
            switch (input.nextInt()) {
                
                case 1:
                    System.out.println("Enter Name: ");
                    String patient = input.next();
                    list.insertEnd(patient);
                    System.out.println("Succesfully Recorded.");
                    break;
                case 8:
                    System.out.println("Exiting Program. Thank You!");
                    return;

            }

        }
    }

}
