package cc006_bsit1a_verginiza;

import java.util.Scanner;

public class StackScannerImproved {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int stacksize, choice;

        System.out.print("Enter stack size: ");
        stacksize = sc.nextInt();

        Stacks stacks = new Stacks(stacksize);
        PrintDisplay();

        do {
            choice = sc.nextInt();

            switch (choice) {
                case 1 -> {
                    boolean full = stacks.isFull();
                    if (full) {
                        System.out.println("Stack is full! ");
                        PrintDisplay();
                        break;
                    }

                    System.out.print("--> ");
                    int input = sc.nextInt();
                    stacks.push(input);

                    System.out.println("Successfully Pushed!");
                    PrintDisplay();
                }
                case 2 -> {
                    try {

                        stacks.pop();
                        PrintDisplay();

                    } catch (ArrayIndexOutOfBoundsException e) {
                        System.out.println("You can't pop on an empty stack!");
                        PrintDisplay();
                    }
                }
                case 3 -> {

                    try {
                        int top = stacks.Top();
                        System.out.println("Stack top: " + top);
                        PrintDisplay();
                    } catch (ArrayIndexOutOfBoundsException e) {
                        System.out.println("Stack is empty!");
                        PrintDisplay();
                    }
                }

                case 4 -> {
                    boolean isEmpty = stacks.isEmpty();
                    if (isEmpty) {

                        System.out.println("Stack is empty!");
                        PrintDisplay();

                    } else {
                        System.out.println("Stack has content/s.");
                        PrintDisplay();
                    }
                }

                case 5 -> {
                    boolean isfull = stacks.isFull();

                    if (isfull) {
                        System.out.println("Stack is full!");
                        PrintDisplay();
                    } else {

                        System.out.println("Stack is not full.");
                        PrintDisplay();
                    }
                }

                case 6 -> {
                    int value = stacks.Count();
                    if (value == -1) {

                        System.out.println("Stacks counted: " + value + 1);
                    } else {
                        System.out.println("Stacks counted: " + value);
                        PrintDisplay();
                    }
                }

                case 7 ->
                    System.out.println("Exiting Program");

                default -> {
                    System.out.println("Out of range. Please try again.");
                    PrintDisplay();
                }
            }

        } while (choice != 7);

    }

    static void PrintDisplay() {
        System.out.print("""
                         ===MENU===
                         [1]Push
                         [2]Pop
                         [3]View Top 
                         [4]Check if empty
                         [5]Check if full
                         [6]Count Stacks
                         [7]EXIT
                         
                         Choice: """);
    }

}
