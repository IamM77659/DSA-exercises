/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package graphs;

import java.util.ArrayList;
import java.util.Queue;
import java.util.LinkedList;

/**
 *
 * @author Students Account
 */
public class Graph {

    ArrayList<Node> nodes;
    
    int[][] matrix;
    
    

    Graph(int size) {
        nodes = new ArrayList<>();
        matrix = new int[size][size];
    }

    public void addNode(Node node) {
        nodes.add(node);

    }

    public void addEdge(int src, int dst) {
        if (src < 0 || src >= matrix.length || dst < 0 || dst >= matrix[src].length) {
            System.out.println("Invalid input. Provided parameters are out of bounds.");
            return;
        }
        matrix[src][dst] = 1;
    }

    public boolean checkEdge(int src, int dst) {
       if(matrix [src][dst] == 1){
           return true;
       }
       return false;
    }

    public void displayGraph() {
        System.out.print("  ");
        for (Node node : nodes) {
            System.out.print(node.data + " ");

        }
        System.out.println();
        for (int x = 0; x < nodes.size(); x++) {
            System.out.print(nodes.get(x).data + " ");
            for (int y = 0; y < nodes.size(); y++) {
                System.out.print(matrix[x][y] + " ");

            }
            System.out.println();
        }

    }
    
    public void bfs(int startIndex){
        boolean[] visited = new boolean[nodes.size()];
        Queue<Integer> store = new LinkedList<>();
        store.add(startIndex);
        visited[startIndex] = true;
        
    }

}
