/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package graphs;

import java.util.Scanner;

/**
 *
 * @author Students Account
 */
public class GraphActivity {

    /**
     * @param args the command line arguments
     */
    static void Menu() {
        System.out.print(""" 
       
                         [1] Add intersection
                         [2] Connect intersections with roads
                         [3] Display Road Network
                         [4] Find Connected Areas
                         [5] List Roads for Maintenance
                         [6] Identify isolated Intersections
                         [0] Exit
                         >
                         
                          """);
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Graph graph = new Graph(10);
        String data = "";

        while (true) {
            System.out.println();
            Menu();
            int choice = input.nextInt();

            switch (choice) {

                case 1:

                    System.out.print("Enter intersection name: ");
                    data = input.nextLine();
                    input.next();
                    graph.addNode(new Node(data));

                    System.out.println("");
                    System.out.println("Successfully inserted.");
                    break;
                case 2:
                case 3:
                    System.out.println("Display in Matrix");
                    graph.displayGraph();
                    break;

                    
                case 5:

                case 0:
                    System.out.println("Exiting program. Thank you!");
                    return;

            }

        }

    }

}
