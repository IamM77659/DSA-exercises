/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package graphv2;

import java.util.Scanner;

/**
 *
 * @author Marbs
 */
public class Roader {

    /**
     * @param args the command line arguments
     */
    static void Menu() {
        System.out.print(""" 
       
                         [1] Add intersection
                         [2] Connect intersections with roads
                         [3] Display Road Network
                         [4] Find Connected Areas
                         [5] List Roads for Maintenance
                         [6] Identify isolated Intersections
                         [0] Exit
                         >
                         
                          """);
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Graph graph = new Graph(10);
        String data = "";

        while (true) {
            System.out.println();
            Menu();
            int choice = input.nextInt();

            switch (choice) {

                case 1:

                    System.out.print("Enter intersection name: ");
                    data = input.next();
                    input.nextLine();

                    graph.addNode(new Node(data));

                    System.out.println("");
                    System.out.println("Successfully inserted.");
                    break;
                case 2:
                    if (graph.isEmpty()) {
                        System.out.println("Graph is empty. Please add an intersection first.");
                        break;
                    }
                    System.out.print("Available intersection/s: ");
                    graph.dispAvailableNodes();
                    System.out.println("");

                    System.out.print("Enter intersection name (From): ");
                    String from = input.next();

                    System.out.print("Enter intersection name (to): ");
                    String to = input.next();

                    int FROM = graph.findIndex(from);
                    int TO = graph.findIndex(to);

                    boolean checkifAdded = graph.addEdge(FROM, TO);
                    if (!checkifAdded) {
                        System.out.println(""" 
                                           One or two of the provided intersections 
                                           does not exist. Please add them first. """);
                        break;
                    }else{
                        System.out.println("Intersections Connected.");
                    }

                    break;
                case 3:
                    System.out.println("Display in Matrix");
                    graph.displayGraph();
                    break;
                case 4:
                    
                    break;
                case 5:
                   
                    break;
                case 0:
                    System.out.println("Exiting program. Thank you!");
                    return;
                default:
                    System.out.println("Invalid input. Please try again.");
                    break;

            }

        }
    }

}
