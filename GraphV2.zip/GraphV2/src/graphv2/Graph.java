
package graphv2;

/**
 *
 * @author WIFI SERVER
 */
import java.util.ArrayList;
import java.util.Queue;
import java.util.LinkedList;

public class Graph {

    ArrayList<Node> nodes;
    //private int lastFoundIndex = -1;
    int[][] matrix;

    Graph(int size) {
        nodes = new ArrayList<>();
        matrix = new int[size][size];
    }

    public void addNode(Node node) {
        nodes.add(node);

    }

    public boolean addEdge(int src, int dst) {
        if (src < 0 || src >= matrix.length || dst < 0 || dst >= matrix[src].length) {
            return false;
            
        }

        matrix[src][dst] = 1;
        return true; 
    }

    public boolean checkEdge(int src, int dst) {
        if (matrix[src][dst] == 1) {
            return true;
        }
        return false;
    }

    public void displayGraph() {
        System.out.print("   ");
        for (int i = 0; i < matrix.length; i++) {
            if (i < nodes.size()) {
                System.out.print(nodes.get(i).data + "   ");
            } else {
                System.out.print("   ");
            }
        }
        System.out.println();

        for (int x = 0; x < matrix.length; x++) {
            if (x < nodes.size()) {
                System.out.print(nodes.get(x).data + "  ");
            } else {
                System.out.print("   ");
            }
            for (int y = 0; y < matrix.length; y++) {
                System.out.print(matrix[x][y] + "   ");
            }
            System.out.println();
        }

    }

    public void dispAvailableNodes() {
        for (int i = 0; i < matrix.length; i++) {
            if (i < nodes.size()) {
                System.out.print(nodes.get(i).data + " ");
            }
        }
    }

    public boolean isEmpty() {
        return nodes.isEmpty();
    }

    public int findIndex(String data) {
        for (int i = 0; i < nodes.size(); i++) {
            String nodedata = nodes.get(i).data;
            if (nodedata.equalsIgnoreCase(data.trim())) {
                return i;
            }
        }

        System.out.println("No match found.");
        return -1;
    }

   

}
