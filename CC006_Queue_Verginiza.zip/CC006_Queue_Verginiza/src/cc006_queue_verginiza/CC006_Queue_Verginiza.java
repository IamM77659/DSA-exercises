/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cc006_queue_verginiza;

import java.util.Scanner;

/**
 *
 * @author Students Account
 */
public class CC006_Queue_Verginiza {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int queuesize;
        String choice = "E";

        System.out.print("Enter queue size (1-10): ");
        queuesize = sc.nextInt();

        while (queuesize > 10) {
            queuesize = 0;
            System.out.println("Out of range! Please try again.");
            System.out.print("Enter queue size (1-10): ");
            queuesize = sc.nextInt();
        }

        Queue q = new Queue(queuesize);
        PrintDisplay();
        

        do {
            choice = sc.nextLine();
            
            
            

            switch (choice) {
                case "E":
                    System.out.print("--> ");
                    int input = sc.nextInt();
                    q.enqueue(input);

                    System.out.println("Queued.");
                    PrintDisplay();
                    break;

                case "D":
                    if (q.isEmpty()) {
                        q.dequeue();
                    } else {
                        q.dequeue();
                        System.out.println("Dequeued.");
                    }

                    PrintDisplay();
                    break;

                case "R":
                    if (!q.isEmpty()) {

                        System.out.println("Rear value is: " + q.rear());
                    } else {
                        System.out.println("Queue is empty!");
                    }
                    PrintDisplay();
                    break;

                case "F":
                    if (!q.isEmpty()) {
                        System.out.println("Front value is: " + q.peek());
                    } else {
                        System.out.println("Queue is empty!");
                    }
                    PrintDisplay();
                    break;

                case "M":
                    if (q.isEmpty()) {
                        System.out.println("Queue is Empty.");
                    } else {
                        System.out.println("Queue is not Empty.");
                    }

                    PrintDisplay();
                    break;
                case "U":
                    if (q.isFull()) {
                        System.out.println("Queue is full.");
                    } else {
                        System.out.println("Queue is not full.");
                    }
                    PrintDisplay();
                    break;

                case "I":
                    System.out.print("Queue: ");
                    q.displayQueue();

                    PrintDisplay();
                    break;

                case "X":
                    System.out.println("Exiting Program.");
                    return;

            }

        } while (choice != "X");

    }

    static void PrintDisplay() {
        System.out.print("""
                         ===MENU===
                         [E]ENQUEUE
                         [D]DEQUEUE
                         [R]REAR
                         [F]FRONT
                         E[M]PTY
                         F[U]LL
                         D[I]SPLAY
                         E[X]IT 
                         
                         Choice: """);
    }

}
