package cc006_queue_verginiza;

public class Queue {

    private int[] myArray;
    private int front, rear, count, maxSize;

    //constructor
    public Queue(int size) {
        myArray = new int[size];
        count = 0;
        front = -1;
        rear = -1;
        maxSize = size;
    }

    public void enqueue(int add) {
        if (isFull() == false) { // rear = 7 maxSize-1 = 7 if(7==7)
            if (rear == maxSize - 1) { //rear = 7
                rear = (rear%(maxSize-1)-1); //rear = -1
            }
            if (front == -1) {
                front = 0;
            }
            myArray[++rear] = add;
            count++;
        } else {
            System.out.println("Queue is full.");
        }
    }

    public void dequeue() {
        if (isEmpty() == false) {
            if (front == maxSize - 1) {
                front = front%(maxSize -1 );
            }
            myArray[front++] = 0;
            count--;
        } else {
            System.out.println("Queue is empty.");
        }
    }

    public boolean isFull() {
        return count == maxSize;
    }

    public boolean isEmpty() {
        return count == 0;
    }

    public int queueCount() {
        return count;
    }

    public int peek() {
        if (!isEmpty()) {
            return myArray[front];
        } else {
            System.out.println("Queue is empty.");
            return -1;
        }
    }

    public int rear() {
        if (!isEmpty()) {
            return myArray[rear];
        } else {
            System.out.println("Queue is empty.");
            return -1;
        }
    }

    public void displayQueue() {
        if (isEmpty() == true) {
            System.out.println("Queue is empty. ");
        } else {
            if (front < rear) {
                for (int i = front; i <= rear; i++) {
                    System.out.print(myArray[i] + " ");
                }
            } else if (front > rear) {
                for (int i = front; i < maxSize; i++) {
                    System.out.print(myArray[i] + " ");
                }
                for (int i = 0; i <= rear; i++) {
                    System.out.print(myArray[i] + " ");
                }
            }
        }
    }
}
