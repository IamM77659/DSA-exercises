/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cc006_bsit1a_verginiza;

import java.util.Scanner;

/**
 *
 * @author Students Account
 */
public class CC006_BSIT1A_Stacks_Verginiza {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int stacksize, choice;

        System.out.print("Enter stack size: ");
        stacksize = sc.nextInt();

        Stacks stacks = new Stacks(stacksize);
        PrintDisplay();

        do {
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    for (int i = 0; i < stacksize; i++) {
                        System.out.print("--> ");
                        int input = sc.nextInt();
                        stacks.push(input);
                    }
                    System.out.println("Successfully Pushed!");
                    break;
                case 2:

                    stacks.pop();
                    System.out.println("Popped!");

                    break;
                case 3://stack top

                    System.out.println("Top valus is: " + stacks.Top());
                    break;

                case 4:

                    boolean isEmpty = stacks.isEmpty();
                    if (isEmpty) {

                        System.out.println("Stack is empty!");

                    } else {
                        System.out.println("Stack has contents.");
                    }

                    break;

                case 5:
                    boolean full = stacks.isFull();

                    if (full) {
                        System.out.println("Stack if full!");
                    } else {
                        System.out.println("Stack is not full.");
                    }
                    break;

                case 6:

                    System.out.println("Stacks counted: " + stacks.Count());
                    break;

                case 7:
                    
                    System.out.println("Exiting Program");
                    break;
                
                default:
                    System.out.println("Out of range. Please try again.");
                    break;
            }

        } while (choice != 7);
        
        
    }

    static void PrintDisplay() {
        System.out.print("===MENU===\n[1]Push\n"
                + "[2]Pop\n[3]View Top \n"
                + "[4]Check if empty\n[5]Check if full\n[6]Count Stacks\n"
                + "[7]EXIT\n"
                + "\nChoice: ");
    }

}
